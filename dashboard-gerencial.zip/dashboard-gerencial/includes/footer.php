<?php

?>
<footer class="text-center py-4 mt-5" style="background:#e8f5e9; color:#388e3c;">
    <small>© <?php echo date('Y'); ?> Rumo à Meta - O Boticário</small>
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
